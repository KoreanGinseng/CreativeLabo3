#pragma once

#include	"Mof.h"

#define		GAMEFRAMETIME			(1.0f / 60.0f)

//�d��
#define		GRAVITY					(0.01f)